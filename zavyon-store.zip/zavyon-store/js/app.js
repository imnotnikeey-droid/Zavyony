/* ZAVYON — shared behaviour: chrome, category gate, listings, product page, WhatsApp ordering */
(function () {
  "use strict";
  var C = window.ZAVYON_CONFIG;
  var PRODUCTS = (window.ZAVYON_PRODUCTS || []).map(function (p) {
    p.images = p.images || []; p.sizes = p.sizes || []; p.colours = p.colours || [];
    p.details = p.details || []; p.specs = p.specs || {};
    return p;
  });
  var PAGE = document.body.getAttribute("data-page");
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var inr = function (n) { return "\u20B9" + Number(n).toLocaleString("en-IN"); };
  var cat = function (slug) { return C.categories.filter(function (c) { return c.slug === slug; })[0]; };
  var param = function (k) { return new URLSearchParams(location.search).get(k) || ""; };
  var ARROW = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><path d="M7 17L17 7M8 7h9v9"/></svg>';

  /* ---------- WhatsApp ---------- */
  function absUrl(path) {
    var base = C.siteUrl ? C.siteUrl.replace(/\/$/, "") + "/" : new URL(".", location.href).href;
    return new URL(path, base).href;
  }
  function productUrl(p) { return absUrl("product.html?id=" + encodeURIComponent(p.id)); }
  function waLink(p, qty, size, colour) {
    var c = cat(p.category);
    var variant = [size, colour].filter(Boolean).join(" / ");
    var lines = [
      "Hello ZAVYON! I would like to order the following product.", "",
      "Product: " + p.name,
      "Category: " + (c ? c.name : p.category),
      "Price: " + inr(p.price),
      "Quantity: " + qty
    ];
    if (variant) lines.push("Size/Colour: " + variant);
    lines.push("Product URL: " + productUrl(p), "", "Please confirm availability, delivery charges, and payment details.", "", "Thank you!");
    return "https://wa.me/" + C.whatsappNumber + "?text=" + encodeURIComponent(lines.join("\n"));
  }
  function waGeneral(text) { return "https://wa.me/" + C.whatsappNumber + "?text=" + encodeURIComponent(text || "Hello ZAVYON! I have a question."); }

  /* ---------- Product helpers ---------- */
  function liveSizes(p) { return p.sizes.filter(function (s) { return s.available !== false; }); }
  function liveColours(p) { return p.colours.filter(function (s) { return s.available !== false; }); }
  function needsOptions(p) { return liveSizes(p).length > 0 || liveColours(p).length > 0; }
  function isAvailable(p) {
    if (p.inStock === false) return false;
    if ((p.sizes.length && !liveSizes(p).length) || (p.colours.length && !liveColours(p).length)) return false;
    return true;
  }
  function img0(p) { return p.images[0] || C.placeholderImage; }
  function card(p) {
    var url = "product.html?id=" + encodeURIComponent(p.id), ok = isAvailable(p), buy;
    if (!ok) buy = '<span class="btn btn-solid is-disabled" aria-disabled="true">Unavailable</span>';
    else if (needsOptions(p)) buy = '<a class="btn btn-solid" href="' + url + '#options">Choose Options</a>';
    else buy = '<a class="btn btn-solid" href="' + waLink(p, 1) + '" target="_blank" rel="noopener">Buy Now</a>';
    return '<article class="card"><a class="pic" href="' + url + '" tabindex="-1" aria-hidden="true"><img src="' + esc(img0(p)) + '" alt="" loading="lazy">' +
      (p.isNew ? '<span class="tag">New</span>' : "") + '</a><div class="meta"><h3><a href="' + url + '">' + esc(p.name) + '</a></h3>' +
      '<p class="price">' + inr(p.price) + '</p><p class="desc">' + esc(p.description) + '</p>' +
      '<span class="avail ' + (ok ? "" : "out") + '">' + (ok ? "Available" : "Currently unavailable") + '</span>' +
      '<div class="actions"><a class="btn btn-line" href="' + url + '">View Details</a>' + buy + '</div></div></article>';
  }
  function emptyCatalogue(scope) {
    return '<div class="empty"><h3>New pieces are being curated</h3><p>' + (scope ? "Nothing is listed in " + esc(scope) + " just yet." : "Nothing is listed just yet.") +
      ' Message us on WhatsApp to ask what is available right now.</p><a class="btn btn-solid" href="' + waGeneral("Hello ZAVYON! What is currently available" + (scope ? " in " + scope : "") + "?") + '" target="_blank" rel="noopener">Ask on WhatsApp</a></div>';
  }
  function setMeta(title, desc, image) {
    document.title = title;
    var d = $('meta[name="description"]'); if (d && desc) d.setAttribute("content", desc);
    [["og:title", title], ["og:description", desc], ["og:image", image && absUrl(image)]].forEach(function (kv) {
      if (!kv[1]) return; var m = $('meta[property="' + kv[0] + '"]');
      if (!m) { m = document.createElement("meta"); m.setAttribute("property", kv[0]); document.head.appendChild(m); }
      m.setAttribute("content", kv[1]);
    });
  }

  /* ---------- Storage (single preference, no tracking) ---------- */
  var KEY = "zavyon:category-gate", memory = null;
  function readPref() { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return memory; } }
  function writePref(v) { memory = v; try { localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { /* storage blocked: preference lasts this visit only */ } }

  /* ---------- Chrome (header / footer) ---------- */
  function chrome() {
    var ig = C.instagramUrl ? '<a href="' + esc(C.instagramUrl) + '" target="_blank" rel="noopener">Instagram</a>' : "";
    var cur = function (p) { return PAGE === p ? ' aria-current="page"' : ""; };
    $("#site-header").innerHTML =
      '<header class="hdr' + (PAGE === "home" ? " over" : "") + '"><div class="wrap"><a class="mark" href="index.html" aria-label="ZAVYON home">ZAVYON</a>' +
      '<button class="menu-btn" aria-expanded="false" aria-controls="nav" aria-label="Open menu"><span></span></button>' +
      '<nav class="nav" id="nav" aria-label="Main"><a href="index.html"' + cur("home") + '>Home</a>' +
      '<button type="button" data-open-gate aria-haspopup="dialog">Collections</button>' +
      '<a href="shop.html"' + cur("shop") + '>Shop All</a><a href="about.html"' + cur("about") + '>About</a><a href="contact.html"' + cur("contact") + '>Contact</a>' + ig +
      '<a class="wa" href="' + waGeneral("Hello ZAVYON!") + '" target="_blank" rel="noopener">WhatsApp</a></nav></div></header>';
    var cats = C.categories.map(function (c) { return '<li><a href="collection.html?c=' + c.slug + '">' + esc(c.name) + "</a></li>"; }).join("");
    $("#site-footer").innerHTML =
      '<footer class="ftr"><div class="wrap"><div class="cols"><div><span class="mark">ZAVYON</span><p style="max-width:32ch;opacity:.8">A curated multi-category shopping brand. Four worlds. One signature.</p></div>' +
      "<div><h4>Collections</h4><ul>" + cats + '</ul></div><div><h4>Explore</h4><ul><li><a href="shop.html">Shop All</a></li><li><a href="about.html">About</a></li><li><a href="contact.html">Contact</a></li>' +
      (C.instagramUrl ? '<li><a href="' + esc(C.instagramUrl) + '" target="_blank" rel="noopener">Instagram</a></li>' : "") + '</ul></div>' +
      '<div><h4>Orders &amp; Help</h4><ul><li><a href="' + waGeneral("Hello ZAVYON!") + '" target="_blank" rel="noopener">WhatsApp ' + esc(C.whatsappDisplay) + '</a></li>' +
      '<li><a href="policies.html#shipping">Shipping &amp; Returns</a></li><li><a href="policies.html#privacy">Privacy</a></li><li><a href="policies.html#terms">Terms</a></li></ul></div></div>' +
      '<div class="fine"><span>\u00A9 ' + new Date().getFullYear() + ' ZAVYON</span><span>Orders are enquiries confirmed directly by ZAVYON on WhatsApp.</span></div></div></footer>';

    var hdr = $(".hdr"), btn = $(".menu-btn"), nav = $("#nav");
    btn.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      btn.setAttribute("aria-expanded", open); btn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      hdr.classList.toggle("menu-open", open); document.body.classList.toggle("locked", open);
    });
    $$("#nav a").forEach(function (a) { a.addEventListener("click", function () { if (nav.classList.contains("open")) btn.click(); }); });
    if (PAGE === "home") {
      var onScroll = function () { hdr.classList.toggle("over", window.scrollY < 40); };
      onScroll(); window.addEventListener("scroll", onScroll, { passive: true });
    }
  }

  /* ---------- Category gate (signature popup) ---------- */
  var gate, lastFocus;
  function buildGate() {
    var cards = C.categories.map(function (c) {
      return '<li><a class="gate-card" href="collection.html?c=' + c.slug + '" data-cat="' + c.slug + '"><img src="' + esc(c.image) + '" alt="" loading="eager">' +
        '<span class="no">' + c.number + '</span><span class="arr">' + ARROW + '</span><span class="tx"><h3>' + esc(c.name.toUpperCase()) + "</h3><p>" + esc(c.tagline) + "</p></span></a></li>";
    }).join("");
    gate = document.createElement("div");
    gate.className = "gate"; gate.setAttribute("role", "dialog"); gate.setAttribute("aria-modal", "true"); gate.setAttribute("aria-labelledby", "gate-title");
    gate.innerHTML = '<div class="gate-panel"><button class="gate-x" type="button" aria-label="Close category selection"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M5 5l14 14M19 5L5 19"/></svg></button>' +
      '<div class="gate-top"><span class="mark">ZAVYON</span><h2 id="gate-title">CHOOSE YOUR CATEGORY</h2><p>Discover something made for your world.</p></div>' +
      '<ul class="gate-grid">' + cards + '</ul><p class="gate-foot">FOUR WORLDS. ONE SIGNATURE.</p></div>';
    document.body.appendChild(gate);
    $(".gate-x", gate).addEventListener("click", function () { closeGate(true); });
    gate.addEventListener("mousedown", function (e) { if (e.target === gate) closeGate(true); });
    $$(".gate-card", gate).forEach(function (a) { a.addEventListener("click", function () { writePref({ state: "selected", category: a.getAttribute("data-cat"), at: Date.now() }); }); });
    gate.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { closeGate(true); return; }
      if (e.key !== "Tab") return;
      var f = $$("a[href],button", gate), first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
  }
  function openGate() {
    if (!gate) buildGate();
    lastFocus = document.activeElement; document.body.classList.add("locked");
    var main = $("main"); if (main) main.setAttribute("inert", ""); var h = $("#site-header"); if (h) h.setAttribute("inert", "");
    requestAnimationFrame(function () { gate.classList.add("show"); setTimeout(function () { $(".gate-card", gate).focus(); }, 80); });
  }
  function closeGate(remember) {
    if (!gate) return;
    gate.classList.remove("show"); document.body.classList.remove("locked");
    var main = $("main"); if (main) main.removeAttribute("inert"); var h = $("#site-header"); if (h) h.removeAttribute("inert");
    if (remember) writePref({ state: "dismissed", at: Date.now() });
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  function initGate() {
    $$("[data-open-gate]").forEach(function (b) { b.addEventListener("click", function () {
      var nav = $("#nav"); if (nav && nav.classList.contains("open")) $(".menu-btn").click();
      openGate();
    }); });
    if (PAGE === "home" && !readPref()) setTimeout(openGate, 500);   // first visit only, homepage only
  }

  /* ---------- Listings (collection / shop / home sections) ---------- */
  function uniq(a) { return a.filter(function (v, i) { return v && a.indexOf(v) === i; }).sort(); }
  function listing(root, list, scopeName, showCategoryFilter) {
    var subs = uniq(list.map(function (p) { return p.subcategory; }));
    var sizes = uniq([].concat.apply([], list.map(function (p) { return p.sizes.map(function (s) { return s.label; }); })));
    var cols = uniq([].concat.apply([], list.map(function (p) { return p.colours.map(function (c) { return c.name; }); })));
    var sel = function (id, label, opts) { return '<div class="f"><label for="' + id + '">' + label + '</label><select id="' + id + '"><option value="">All</option>' + opts.map(function (o) { return '<option value="' + esc(o[0]) + '">' + esc(o[1]) + "</option>"; }).join("") + "</select></div>"; };
    root.innerHTML =
      '<div class="tools" role="search"><div class="f grow"><label for="q">Search</label><input id="q" type="search" placeholder="Search by name or description" value="' + esc(param("q")) + '"></div>' +
      (showCategoryFilter ? sel("fc", "Category", C.categories.map(function (c) { return [c.slug, c.name]; })) : "") +
      (subs.length ? sel("fs", "Type", subs.map(function (s) { return [s, s]; })) : "") +
      (sizes.length ? sel("fz", "Size", sizes.map(function (s) { return [s, s]; })) : "") +
      (cols.length ? sel("fk", "Colour", cols.map(function (s) { return [s, s]; })) : "") +
      '<div class="f"><label for="so">Sort</label><select id="so"><option value="new">Newest</option><option value="lo">Price: low to high</option><option value="hi">Price: high to low</option><option value="az">Name: A to Z</option></select></div>' +
      '<label class="check"><input type="checkbox" id="ia"> Available only</label></div>' +
      '<p class="count" id="count" role="status" aria-live="polite"></p><div class="grid" id="grid"></div>';
    if (showCategoryFilter && param("c")) $("#fc", root).value = param("c");
    function run() {
      var q = $("#q", root).value.trim().toLowerCase(), g = function (id) { var e = $("#" + id, root); return e ? e.value : ""; };
      var out = list.filter(function (p) {
        if (q && (p.name + " " + p.description + " " + (p.subcategory || "")).toLowerCase().indexOf(q) < 0) return false;
        if (g("fc") && p.category !== g("fc")) return false;
        if (g("fs") && p.subcategory !== g("fs")) return false;
        if (g("fz") && !p.sizes.some(function (s) { return s.label === g("fz") && s.available !== false; })) return false;
        if (g("fk") && !p.colours.some(function (c) { return c.name === g("fk") && c.available !== false; })) return false;
        if ($("#ia", root).checked && !isAvailable(p)) return false;
        return true;
      });
      var s = g("so");
      out.sort(function (a, b) { return s === "lo" ? a.price - b.price : s === "hi" ? b.price - a.price : s === "az" ? a.name.localeCompare(b.name) : String(b.addedOn || "").localeCompare(String(a.addedOn || "")); });
      $("#count", root).textContent = list.length ? out.length + (out.length === 1 ? " piece" : " pieces") : "";
      $("#grid", root).innerHTML = !list.length ? emptyCatalogue(scopeName) :
        out.length ? out.map(card).join("") : '<div class="empty"><h3>No pieces match</h3><p>Try a different search or clear a filter.</p><button class="btn btn-line" type="button" id="clr">Clear filters</button></div>';
      var clr = $("#clr", root); if (clr) clr.addEventListener("click", function () { $$("input[type=search],select", root).forEach(function (e) { e.value = ""; }); $("#so", root).value = "new"; $("#ia", root).checked = false; run(); });
    }
    $$("input,select", root).forEach(function (e) { e.addEventListener("input", run); e.addEventListener("change", run); });
    run();
  }

  /* ---------- Pages ---------- */
  function pageHome() {
    var worlds = $("#worlds");
    worlds.innerHTML = C.categories.map(function (c, i) {
      return '<a class="world world-' + (i + 1) + '" href="collection.html?c=' + c.slug + '"><img src="' + esc(c.image) + '" alt="" loading="lazy"><span class="arrow">' + ARROW + '</span><div><span class="label">' + c.number + '</span><h3>' + esc(c.name) + "</h3><p>" + esc(c.tagline) + "</p></div></a>";
    }).join("");
    var byNew = PRODUCTS.slice().sort(function (a, b) { return String(b.addedOn || "").localeCompare(String(a.addedOn || "")); });
    var nw = byNew.filter(function (p) { return p.isNew; }).slice(0, 4); if (!nw.length) nw = byNew.slice(0, 4);
    var ft = PRODUCTS.filter(function (p) { return p.featured; }).slice(0, 4);
    $("#new-grid").innerHTML = nw.length ? nw.map(card).join("") : emptyCatalogue("");
    $("#feat-grid").innerHTML = ft.length ? ft.map(card).join("") : '<div class="empty"><h3>Featured finds arrive soon</h3><p>Our favourite pieces will be gathered here as the collection grows.</p></div>';
    var ig = $("#ig"); if (ig && C.instagramUrl) { ig.classList.remove("hidden"); $("#ig-link").href = C.instagramUrl; }
  }
  function pageCollection() {
    var c = cat(param("c")), root = $("#listing");
    if (!c) { $("#cat-hero").innerHTML = ""; root.innerHTML = '<div class="empty"><h3>Collection not found</h3><p>Choose one of our four collections.</p><button class="btn btn-solid" type="button" data-open-gate>Choose a category</button></div>'; $("[data-open-gate]", root).addEventListener("click", openGate); return; }
    setMeta(c.name + " \u2014 ZAVYON", c.intro, c.image);
    $("#cat-hero").innerHTML = '<img src="' + esc(c.image) + '" alt=""><div class="wrap"><span class="label">Collection ' + c.number + '</span><h1 class="serif">' + esc(c.name) + "</h1><p>" + esc(c.intro) + "</p></div>";
    $("#crumb-name").textContent = c.name;
    var others = C.categories.filter(function (x) { return x.slug !== c.slug; }).map(function (x) { return '<a href="collection.html?c=' + x.slug + '" style="border-bottom:1px solid;margin-right:18px">' + esc(x.name) + "</a>"; }).join("");
    $("#other-cats").innerHTML = '<p class="label" style="margin-bottom:14px">Other collections</p>' + others;
    listing(root, PRODUCTS.filter(function (p) { return p.category === c.slug; }), c.name, false);
  }
  function pageShop() { listing($("#listing"), PRODUCTS, "", true); }

  function pageProduct() {
    var p = PRODUCTS.filter(function (x) { return x.id === param("id"); })[0], root = $("#pdp");
    if (!p) { root.innerHTML = '<div class="empty" style="grid-column:1/-1"><h3>Product not found</h3><p>This piece may have been removed or the link may be incorrect.</p><a class="btn btn-solid" href="shop.html">Shop All</a></div>'; return; }
    var c = cat(p.category), ok = isAvailable(p), size = "", colour = "", qty = 1, max = p.maxQty || 10, imgs = p.images.length ? p.images : [C.placeholderImage];
    setMeta(p.name + " \u2014 ZAVYON", p.description, imgs[0]);
    var ld = { "@context": "https://schema.org", "@type": "Product", name: p.name, description: p.description, image: imgs.map(absUrl), category: c ? c.name : p.category, offers: { "@type": "Offer", priceCurrency: "INR", price: String(p.price), availability: ok ? "https://schema.org/InStock" : "https://schema.org/OutOfStock", url: productUrl(p) } };
    var s = document.createElement("script"); s.type = "application/ld+json"; s.textContent = JSON.stringify(ld); document.head.appendChild(s);
    $("#crumb").innerHTML = '<a href="index.html">Home</a> / <a href="collection.html?c=' + p.category + '">' + esc(c ? c.name : "") + "</a> / " + esc(p.name);

    var thumbs = imgs.length > 1 ? '<div class="thumbs">' + imgs.map(function (u, i) { return '<button type="button" data-i="' + i + '" aria-label="Show image ' + (i + 1) + '" aria-current="' + (i === 0) + '"><img src="' + esc(u) + '" alt=""></button>'; }).join("") + "</div>" : "";
    var sizeHtml = p.sizes.length ? '<fieldset class="opt" id="options"><legend>Size<span class="chosen" id="size-v"></span></legend><div class="chips">' + p.sizes.map(function (z) { var off = z.available === false; return '<button type="button" class="chip" data-size="' + esc(z.label) + '" aria-pressed="false"' + (off ? ' disabled title="Unavailable"' : "") + ">" + esc(z.label) + "</button>"; }).join("") + "</div></fieldset>" : "";
    var colHtml = p.colours.length ? '<fieldset class="opt"' + (p.sizes.length ? "" : ' id="options"') + '><legend>Colour<span class="chosen" id="col-v"></span></legend><div class="chips">' + p.colours.map(function (z) { var off = z.available === false; return '<button type="button" class="chip" data-col="' + esc(z.name) + '" aria-pressed="false"' + (off ? ' disabled title="Unavailable"' : "") + ">" + (z.hex ? '<i style="background:' + esc(z.hex) + '"></i>' : "") + esc(z.name) + "</button>"; }).join("") + "</div></fieldset>" : "";
    var specKeys = Object.keys(p.specs);
    root.innerHTML = '<div class="gallery"><div class="main"><img id="main-img" src="' + esc(imgs[0]) + '" alt="' + esc(p.name) + '"></div>' + thumbs + "</div>" +
      '<div class="info"><span class="label muted">' + esc(c ? c.name : "") + '</span><h1 class="serif">' + esc(p.name) + '</h1><p class="price">' + inr(p.price) + '</p><span class="avail ' + (ok ? "" : "out") + '">' + (ok ? "Available" : "Currently unavailable") + "</span>" +
      '<p class="lead">' + esc(p.description) + "</p>" + sizeHtml + colHtml +
      (ok ? '<div class="opt"><span class="lg">Quantity</span><div class="qty"><button type="button" id="dec" aria-label="Decrease quantity">\u2212</button><output id="qv" aria-live="polite">1</output><button type="button" id="inc" aria-label="Increase quantity">+</button></div></div>' : "") +
      '<p class="err" id="err" role="alert"></p>' +
      (ok ? '<a class="btn btn-solid btn-wide" id="buy" href="#" target="_blank" rel="noopener">Buy Now</a>' : '<span class="btn btn-solid btn-wide is-disabled" aria-disabled="true">Currently unavailable</span>') +
      '<p class="note">Buy Now opens WhatsApp with your order details ready to send. No payment is taken on this site \u2014 ZAVYON confirms availability, delivery and payment with you directly.</p>' +
      '<div class="acc">' + (p.details.length ? '<details open><summary>Details</summary><div class="body"><ul>' + p.details.map(function (d) { return "<li>" + esc(d) + "</li>"; }).join("") + "</ul></div></details>" : "") +
      (specKeys.length ? '<details open><summary>Specifications</summary><div class="body"><dl>' + specKeys.map(function (k) { return "<dt>" + esc(k) + "</dt><dd>" + esc(p.specs[k]) + "</dd>"; }).join("") + "</dl></div></details>" : "") + "</div></div>";

    $$(".thumbs button", root).forEach(function (b) { b.addEventListener("click", function () { $("#main-img").src = imgs[+b.getAttribute("data-i")]; $$(".thumbs button", root).forEach(function (o) { o.setAttribute("aria-current", o === b); }); }); });
    function pick(attr, valId, setter) { $$("[" + attr + "]", root).forEach(function (b) { b.addEventListener("click", function () { $$("[" + attr + "]", root).forEach(function (o) { o.setAttribute("aria-pressed", o === b); }); setter(b.getAttribute(attr)); $("#" + valId).textContent = b.getAttribute(attr); $("#err").textContent = ""; }); }); }
    pick("data-size", "size-v", function (v) { size = v; }); pick("data-col", "col-v", function (v) { colour = v; });
    if (ok) {
      var upd = function () { $("#qv").textContent = qty; $("#buy").href = waLink(p, qty, size, colour); };
      $("#dec").addEventListener("click", function () { qty = Math.max(1, qty - 1); upd(); });
      $("#inc").addEventListener("click", function () { qty = Math.min(max, qty + 1); upd(); });
      $$(".chip", root).forEach(function (b) { b.addEventListener("click", upd); });
      $("#buy").addEventListener("click", function (e) {
        var miss = []; if (liveSizes(p).length && !size) miss.push("a size"); if (liveColours(p).length && !colour) miss.push("a colour");
        if (miss.length) { e.preventDefault(); $("#err").textContent = "Please choose " + miss.join(" and ") + " before ordering."; var o = $("#options"); if (o) o.scrollIntoView({ block: "center" }); return; }
        upd();
      });
      upd();
    }
    var rel = PRODUCTS.filter(function (x) { return x.category === p.category && x.id !== p.id; }).slice(0, 4);
    var rs = $("#related"); if (rel.length) { $("#related-grid").innerHTML = rel.map(card).join(""); } else if (rs) { rs.classList.add("hidden"); }
  }

  function pageContact() {
    var e = $("#c-email"), a = $("#c-addr"), i = $("#c-ig");
    $("#c-wa").href = waGeneral("Hello ZAVYON!"); $("#c-wa").textContent = "WhatsApp " + C.whatsappDisplay;
    e.innerHTML = C.email ? '<a href="mailto:' + esc(C.email) + '" style="border-bottom:1px solid">' + esc(C.email) + "</a>" : '<span class="todo">Business email \u2014 to be added</span>';
    if (C.address) a.innerHTML = esc(C.address); else a.closest(".box").classList.add("hidden");
    i.innerHTML = C.instagramUrl ? '<a href="' + esc(C.instagramUrl) + '" target="_blank" rel="noopener" style="border-bottom:1px solid">Visit our Instagram</a>' : '<span class="todo">Instagram profile \u2014 to be added</span>';
  }

  /* ---------- Boot ---------- */
  chrome();
  ({ home: pageHome, collection: pageCollection, shop: pageShop, product: pageProduct, contact: pageContact }[PAGE] || function () {})();
  initGate();
})();
