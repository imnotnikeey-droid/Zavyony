/*
  SAMPLE ONLY — DO NOT PUBLISH AS REAL INVENTORY.
  To preview how the shop looks with products, temporarily copy these objects into js/products.js
  (or swap the script tag in the HTML files to point at this file). Replace names, prices and photos with your real items.
*/
window.ZAVYON_PRODUCTS = [
  {
    id: "sample-ceramic-vase",
    name: "Sample — Ceramic Vase",
    category: "home-decor",
    subcategory: "Decorative objects",
    price: 1499,
    description: "Sample listing. A hand-finished ceramic vase for dried stems.",
    details: ["Replace this with your real product description.", "Add as many lines as you need."],
    specs: { Material: "Ceramic", Height: "28 cm", Care: "Wipe with a dry cloth" },
    images: [],                       // e.g. ["assets/products/vase-1.jpg", "assets/products/vase-2.jpg"]
    colours: [{ name: "Ivory", hex: "#F2ECE0", available: true }, { name: "Charcoal", hex: "#292825", available: false }],
    inStock: true, maxQty: 5, isNew: true, featured: true, addedOn: "2026-10-01"
  },
  {
    id: "sample-leather-wallet",
    name: "Sample — Card Wallet",
    category: "fashion-accessories",
    subcategory: "Wallets",
    price: 999,
    description: "Sample listing. A slim wallet with space for six cards.",
    specs: { Material: "Vegan leather" },
    colours: [{ name: "Black", hex: "#111110", available: true }, { name: "Tan", hex: "#B08A5B", available: true }],
    inStock: true, isNew: true, addedOn: "2026-10-05"
  },
  {
    id: "sample-linen-shirt",
    name: "Sample — Linen Shirt",
    category: "garments",
    subcategory: "Shirts",
    price: 1899,
    description: "Sample listing. A relaxed linen shirt for everyday wear.",
    specs: { Fabric: "100% linen", Fit: "Relaxed" },
    sizes: [{ label: "S", available: true }, { label: "M", available: true }, { label: "L", available: true }, { label: "XL", available: false }],
    colours: [{ name: "White", hex: "#FFFFFF", available: true }, { name: "Sand", hex: "#C7B69A", available: true }],
    inStock: true, featured: true, addedOn: "2026-10-10"
  },
  {
    id: "sample-gift-box",
    name: "Sample — Gift Box",
    category: "others",
    price: 799,
    description: "Sample listing. A keepsake box for small treasures.",
    inStock: false, addedOn: "2026-09-20"
  }
];
