/*
  ZAVYON — PRODUCT CATALOGUE  (this is the one file you edit to manage products)

  The catalogue starts EMPTY on purpose, so no invented stock is ever shown to customers.
  Add one object per product to the array below, then redeploy.
  See js/products.sample.js for a fully worked example of every field.

  Required:  id (unique, lowercase-with-dashes), name, category, price (number, INR), description
  Categories: "home-decor" | "fashion-accessories" | "garments" | "others"
  Optional:  subcategory, images[], details[], specs{}, sizes[], colours[], inStock, maxQty, isNew, featured, addedOn
*/
window.ZAVYON_PRODUCTS = [
  // { id: "your-product-id", name: "Product name", category: "home-decor", price: 0, description: "..." },
];
