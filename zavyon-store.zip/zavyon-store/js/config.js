/* ZAVYON — site settings. Edit this file to update contact details and categories. */
window.ZAVYON_CONFIG = {
  brand: "ZAVYON",
  whatsappNumber: "916282047605",          // digits only, with country code
  whatsappDisplay: "+91 62820 47605",
  instagramUrl: "",                         // e.g. "https://www.instagram.com/yourhandle" — Instagram links and showcase stay hidden until set
  email: "",                                // e.g. "hello@yourdomain.com" — shows a placeholder until set
  address: "",                              // optional — leave empty to hide
  siteUrl: "",                              // optional, e.g. "https://zavyon-store.vercel.app" — used in order links; blank = current address
  placeholderImage: "assets/img/placeholder.svg",
  categories: [
    { slug: "home-decor", number: "01", name: "Home Decor", tagline: "Elevate your space.",
      image: "assets/img/home-decor.svg",
      intro: "Warm, architectural pieces for the rooms you live in — decorative objects, table accessories and considered details for the home." },
    { slug: "fashion-accessories", number: "02", name: "Fashion Accessories", tagline: "Define your signature style.",
      image: "assets/img/fashion-accessories.svg",
      intro: "The finishing touches that make an outfit yours. Browse what is currently available, with every variation shown." },
    { slug: "garments", number: "03", name: "Garments", tagline: "Find your everyday statement.",
      image: "assets/img/garments.svg",
      intro: "Wardrobe pieces chosen for how they wear, with sizes and colours listed so you can order with confidence." },
    { slug: "others", number: "04", name: "Others", tagline: "Unexpected finds. Distinctive choices.",
      image: "assets/img/others.svg",
      intro: "A flexible corner for everything that does not fit neatly elsewhere — chosen because it deserves attention." }
  ]
};
