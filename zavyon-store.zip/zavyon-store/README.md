# ZAVYON — Luxury editorial storefront

Static site (HTML, CSS, vanilla JS). No build step, no backend. Orders are WhatsApp enquiries to +91 62820 47605.

## Deploy on Vercel
1. Upload this folder to a Vercel project (drag-and-drop, `vercel` CLI, or a Git repo). Framework preset: **Other**. No build command; output directory: root.
2. Suggested project name: `zavyon-store` → https://zavyon-store.vercel.app

## Preview locally
Run `npx serve .` in this folder and open http://localhost:3000 (opening index.html directly also works).

## Things to edit
| What | Where |
|---|---|
| Instagram link, email, address, site URL | `js/config.js` (Instagram links/showcase stay hidden until you set the URL) |
| Products (names, prices, sizes, colours, photos, stock) | `js/products.js` — starts empty; see `js/products.sample.js` for every field |
| Product photos | Put files in `assets/products/` and list them in the product's `images: []` |
| Category photos / hero | Replace `assets/img/*.svg` with real photography (keep the same file names, or update `js/config.js`; for the hero edit `index.html`) |
| Shipping, returns, terms | `policies.html` |

The included artwork in `assets/img` are tonal placeholders, not photographs. Replace them with real editorial photography before launch.

## How it behaves
- First visit to the homepage shows the category selector. The choice or dismissal is saved in `localStorage` under `zavyon:category-gate` (one preference, no tracking). "Collections" in the navigation reopens it.
- Buy Now builds the exact WhatsApp message and opens `https://wa.me/916282047605?text=…`. Products with sizes/colours require a selection first. Unavailable variants cannot be selected.
- There is **no admin dashboard or database**: a static site cannot host one safely. Products live in `js/products.js`; edit and redeploy.

## Structure
index.html · shop.html · collection.html?c=<slug> · product.html?id=<id> · about.html · contact.html · policies.html
css/style.css · js/config.js · js/products.js · js/app.js · assets/
